﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmHome
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grpJanr = New System.Windows.Forms.GroupBox()
        Me.btnUzasi = New System.Windows.Forms.Button()
        Me.btnFantastika = New System.Windows.Forms.Button()
        Me.btnPrikluchenia = New System.Windows.Forms.Button()
        Me.btnKriminaleta = New System.Windows.Forms.Button()
        Me.btnRomani = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.grpJanr.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Orange
        Me.Label1.Location = New System.Drawing.Point(150, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(489, 57)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Библиотечен каталог"
        '
        'grpJanr
        '
        Me.grpJanr.Controls.Add(Me.btnUzasi)
        Me.grpJanr.Controls.Add(Me.btnFantastika)
        Me.grpJanr.Controls.Add(Me.btnPrikluchenia)
        Me.grpJanr.Controls.Add(Me.btnKriminaleta)
        Me.grpJanr.Controls.Add(Me.btnRomani)
        Me.grpJanr.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.grpJanr.ForeColor = System.Drawing.Color.Black
        Me.grpJanr.Location = New System.Drawing.Point(150, 93)
        Me.grpJanr.Name = "grpJanr"
        Me.grpJanr.Size = New System.Drawing.Size(489, 302)
        Me.grpJanr.TabIndex = 1
        Me.grpJanr.TabStop = False
        Me.grpJanr.Text = "Жанрове"
        '
        'btnUzasi
        '
        Me.btnUzasi.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnUzasi.Font = New System.Drawing.Font("Times New Roman", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.btnUzasi.Location = New System.Drawing.Point(27, 244)
        Me.btnUzasi.Name = "btnUzasi"
        Me.btnUzasi.Size = New System.Drawing.Size(436, 39)
        Me.btnUzasi.TabIndex = 4
        Me.btnUzasi.Text = "Ужаси"
        Me.btnUzasi.UseVisualStyleBackColor = False
        '
        'btnFantastika
        '
        Me.btnFantastika.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.btnFantastika.Font = New System.Drawing.Font("Times New Roman", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.btnFantastika.Location = New System.Drawing.Point(27, 190)
        Me.btnFantastika.Name = "btnFantastika"
        Me.btnFantastika.Size = New System.Drawing.Size(436, 39)
        Me.btnFantastika.TabIndex = 3
        Me.btnFantastika.Text = "Фантастика"
        Me.btnFantastika.UseVisualStyleBackColor = False
        '
        'btnPrikluchenia
        '
        Me.btnPrikluchenia.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnPrikluchenia.Font = New System.Drawing.Font("Times New Roman", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.btnPrikluchenia.Location = New System.Drawing.Point(27, 136)
        Me.btnPrikluchenia.Name = "btnPrikluchenia"
        Me.btnPrikluchenia.Size = New System.Drawing.Size(436, 39)
        Me.btnPrikluchenia.TabIndex = 2
        Me.btnPrikluchenia.Text = "Приключения"
        Me.btnPrikluchenia.UseVisualStyleBackColor = False
        '
        'btnKriminaleta
        '
        Me.btnKriminaleta.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnKriminaleta.Font = New System.Drawing.Font("Times New Roman", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.btnKriminaleta.Location = New System.Drawing.Point(27, 82)
        Me.btnKriminaleta.Name = "btnKriminaleta"
        Me.btnKriminaleta.Size = New System.Drawing.Size(436, 39)
        Me.btnKriminaleta.TabIndex = 1
        Me.btnKriminaleta.Text = "Криминалета"
        Me.btnKriminaleta.UseVisualStyleBackColor = False
        '
        'btnRomani
        '
        Me.btnRomani.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnRomani.Font = New System.Drawing.Font("Times New Roman", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.btnRomani.Location = New System.Drawing.Point(26, 28)
        Me.btnRomani.Name = "btnRomani"
        Me.btnRomani.Size = New System.Drawing.Size(436, 39)
        Me.btnRomani.TabIndex = 0
        Me.btnRomani.Text = "Романи"
        Me.btnRomani.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.Red
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.White
        Me.btnExit.Location = New System.Drawing.Point(707, 359)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(78, 36)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "Изход"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'frmHome
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(797, 407)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.grpJanr)
        Me.Controls.Add(Me.Label1)
        Me.ForeColor = System.Drawing.Color.Coral
        Me.Name = "frmHome"
        Me.Text = "Библиотека"
        Me.grpJanr.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents grpJanr As System.Windows.Forms.GroupBox
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnUzasi As System.Windows.Forms.Button
    Friend WithEvents btnFantastika As System.Windows.Forms.Button
    Friend WithEvents btnPrikluchenia As System.Windows.Forms.Button
    Friend WithEvents btnKriminaleta As System.Windows.Forms.Button
    Friend WithEvents btnRomani As System.Windows.Forms.Button

End Class
