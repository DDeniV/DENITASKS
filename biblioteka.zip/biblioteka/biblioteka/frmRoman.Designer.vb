﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRoman
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.KLabel2 = New System.Windows.Forms.Label()
        Me.KpctOstin = New System.Windows.Forms.PictureBox()
        Me.KgrpJanr = New System.Windows.Forms.GroupBox()
        Me.KpctMarkes = New System.Windows.Forms.PictureBox()
        Me.KpctTolstoi = New System.Windows.Forms.PictureBox()
        Me.KListBox1 = New System.Windows.Forms.ListBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.KComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.KbtnBack = New System.Windows.Forms.Button()
        CType(Me.KpctOstin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.KgrpJanr.SuspendLayout()
        CType(Me.KpctMarkes, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.KpctTolstoi, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'KLabel2
        '
        Me.KLabel2.AutoSize = True
        Me.KLabel2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.KLabel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.KLabel2.Font = New System.Drawing.Font("Times New Roman", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.KLabel2.ForeColor = System.Drawing.Color.DeepPink
        Me.KLabel2.Location = New System.Drawing.Point(12, 9)
        Me.KLabel2.Name = "KLabel2"
        Me.KLabel2.Size = New System.Drawing.Size(190, 57)
        Me.KLabel2.TabIndex = 9
        Me.KLabel2.Text = "Романи"
        '
        'KpctOstin
        '
        Me.KpctOstin.ImageLocation = "https://cache2.24chasa.bg/Images/Cache/850/IMAGE_9961850_40_0.jpg"
        Me.KpctOstin.Location = New System.Drawing.Point(430, 28)
        Me.KpctOstin.Name = "KpctOstin"
        Me.KpctOstin.Size = New System.Drawing.Size(212, 256)
        Me.KpctOstin.TabIndex = 5
        Me.KpctOstin.TabStop = False
        '
        'KgrpJanr
        '
        Me.KgrpJanr.Controls.Add(Me.KpctOstin)
        Me.KgrpJanr.Controls.Add(Me.KpctMarkes)
        Me.KgrpJanr.Controls.Add(Me.KpctTolstoi)
        Me.KgrpJanr.Controls.Add(Me.KListBox1)
        Me.KgrpJanr.Controls.Add(Me.Label3)
        Me.KgrpJanr.Controls.Add(Me.KComboBox1)
        Me.KgrpJanr.Controls.Add(Me.Label1)
        Me.KgrpJanr.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.KgrpJanr.ForeColor = System.Drawing.Color.Black
        Me.KgrpJanr.Location = New System.Drawing.Point(12, 82)
        Me.KgrpJanr.Name = "KgrpJanr"
        Me.KgrpJanr.Size = New System.Drawing.Size(657, 302)
        Me.KgrpJanr.TabIndex = 10
        Me.KgrpJanr.TabStop = False
        Me.KgrpJanr.Text = "Автори и произведения"
        '
        'KpctMarkes
        '
        Me.KpctMarkes.ImageLocation = "https://www.libruse.bg/imagesDB/news/News_1843/thumbs/795648837.jpg"
        Me.KpctMarkes.Location = New System.Drawing.Point(430, 28)
        Me.KpctMarkes.Name = "KpctMarkes"
        Me.KpctMarkes.Size = New System.Drawing.Size(212, 256)
        Me.KpctMarkes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.KpctMarkes.TabIndex = 6
        Me.KpctMarkes.TabStop = False
        '
        'KpctTolstoi
        '
        Me.KpctTolstoi.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR7HkU0izjR8dbEBm_FjGYK8kFMJ" & _
            "GvKsVrMYQciwGtYwA&s"
        Me.KpctTolstoi.Location = New System.Drawing.Point(430, 28)
        Me.KpctTolstoi.Name = "KpctTolstoi"
        Me.KpctTolstoi.Size = New System.Drawing.Size(212, 256)
        Me.KpctTolstoi.TabIndex = 1
        Me.KpctTolstoi.TabStop = False
        '
        'KListBox1
        '
        Me.KListBox1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.KListBox1.FormattingEnabled = True
        Me.KListBox1.ItemHeight = 19
        Me.KListBox1.Items.AddRange(New Object() {"""Война и мир""", """Анна Каренина""", """Възкресение""", """Гордост и предразсъдъци""", """Разум и чувства""", """Ема""", """Сто години самота""", """Любов по време на холера""", """Хроника на една предизвестена смърт"""})
        Me.KListBox1.Location = New System.Drawing.Point(6, 148)
        Me.KListBox1.Name = "KListBox1"
        Me.KListBox1.Size = New System.Drawing.Size(324, 137)
        Me.KListBox1.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.Label3.Location = New System.Drawing.Point(6, 126)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(112, 19)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Произведения"
        '
        'KComboBox1
        '
        Me.KComboBox1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.KComboBox1.FormattingEnabled = True
        Me.KComboBox1.Items.AddRange(New Object() {"Лев Толстой", "Джейн Остин", "Габриел Гарсия Маркес"})
        Me.KComboBox1.Location = New System.Drawing.Point(6, 60)
        Me.KComboBox1.Name = "KComboBox1"
        Me.KComboBox1.Size = New System.Drawing.Size(324, 27)
        Me.KComboBox1.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.Label1.Location = New System.Drawing.Point(6, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(53, 19)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Автор"
        '
        'KbtnBack
        '
        Me.KbtnBack.BackColor = System.Drawing.Color.Red
        Me.KbtnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.KbtnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.KbtnBack.ForeColor = System.Drawing.Color.White
        Me.KbtnBack.Location = New System.Drawing.Point(690, 348)
        Me.KbtnBack.Name = "KbtnBack"
        Me.KbtnBack.Size = New System.Drawing.Size(78, 36)
        Me.KbtnBack.TabIndex = 11
        Me.KbtnBack.Text = "Назад"
        Me.KbtnBack.UseVisualStyleBackColor = False
        '
        'frmRoman
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(780, 405)
        Me.Controls.Add(Me.KLabel2)
        Me.Controls.Add(Me.KgrpJanr)
        Me.Controls.Add(Me.KbtnBack)
        Me.Name = "frmRoman"
        Me.Text = "Романи"
        CType(Me.KpctOstin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.KgrpJanr.ResumeLayout(False)
        Me.KgrpJanr.PerformLayout()
        CType(Me.KpctMarkes, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.KpctTolstoi, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents KLabel2 As System.Windows.Forms.Label
    Friend WithEvents KpctOstin As System.Windows.Forms.PictureBox
    Friend WithEvents KgrpJanr As System.Windows.Forms.GroupBox
    Friend WithEvents KpctMarkes As System.Windows.Forms.PictureBox
    Friend WithEvents KpctTolstoi As System.Windows.Forms.PictureBox
    Friend WithEvents KListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents KComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents KbtnBack As System.Windows.Forms.Button
End Class
