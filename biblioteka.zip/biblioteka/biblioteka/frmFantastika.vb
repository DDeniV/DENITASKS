﻿Public Class frmFantastika

    Private Sub frmFantastika_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        KListBox1.Items.Clear()
        KpctTolstoi.Hide()
        KpctOstin.Hide()
        KpctMarkes.Hide()
    End Sub

    Private Sub KComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KComboBox1.SelectedIndexChanged
        If KComboBox1.SelectedIndex = 0 Then
            KListBox1.Items.Clear()
            KpctTolstoi.Show()
            KpctOstin.Hide()
            KpctMarkes.Hide()
            KListBox1.Items.Add("Война на световете")
            KListBox1.Items.Add("Невидимият човек")
            KListBox1.Items.Add("Машината на времето")
        Else
            KListBox1.Items.Clear()
        End If

        If KComboBox1.SelectedIndex = 1 Then
            KListBox1.Items.Clear()
            KpctOstin.Show()
            KpctTolstoi.Hide()
            KpctMarkes.Hide()
            KListBox1.Items.Add("Лъвът, вещицата и дрешникът")
            KListBox1.Items.Add("Принц Каспиан")
            KListBox1.Items.Add("Пътешествието на Разсъмване")

        End If

        If KComboBox1.SelectedIndex = 2 Then
            KListBox1.Items.Clear()
            KpctMarkes.Show()
            KpctTolstoi.Hide()
            KpctOstin.Hide()
            KListBox1.Items.Add("Игра на тронове")
            KListBox1.Items.Add("Сблъсък на крале")
            KListBox1.Items.Add("Буря от мечове")

        End If
    End Sub

    Private Sub KListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KListBox1.SelectedIndexChanged

    End Sub

    Private Sub KpctOstin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KpctOstin.Click

    End Sub

    Private Sub KbtnBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KbtnBack.Click
        frmHome.Show()
        Me.Close()
    End Sub
End Class