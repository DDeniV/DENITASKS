﻿Public Class frmKriminale

    Private Sub frmKriminale_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        KListBox1.Items.Clear()
        KpctTolstoi.Hide()
        KpctOstin.Hide()
        KpctMarkes.Hide()
    End Sub
    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles KComboBox1.SelectedIndexChanged

        If KComboBox1.SelectedIndex = 0 Then
            KListBox1.Items.Clear()
            KpctTolstoi.Show()
            KpctOstin.Hide()
            KpctMarkes.Hide()
            KListBox1.Items.Add("Големият сън")
            KListBox1.Items.Add("Сбогом, моя красавице")
            KListBox1.Items.Add("Дългото сбогуване")
        Else
            KListBox1.Items.Clear()
        End If

        If KComboBox1.SelectedIndex = 1 Then
            KListBox1.Items.Clear()
            KpctOstin.Show()
            KpctTolstoi.Hide()
            KpctMarkes.Hide()
            KListBox1.Items.Add("Убийство в Ориент експрес")
            KListBox1.Items.Add("Десет малки негърчета")
            KListBox1.Items.Add("Убийството на Роджър Акройд")

        End If

        If KComboBox1.SelectedIndex = 2 Then
            KListBox1.Items.Clear()
            KpctMarkes.Show()
            KpctTolstoi.Hide()
            KpctOstin.Hide()
            KListBox1.Items.Add("Малтийският сокол")
            KListBox1.Items.Add("Червената жътва")
            KListBox1.Items.Add("Кльощавият")

        End If
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KListBox1.SelectedIndexChanged

    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KpctTolstoi.Click

    End Sub

    Private Sub btnBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KbtnBack.Click
        frmHome.Show()
        Me.Close()
    End Sub

    Private Sub KLabel2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KLabel2.Click

    End Sub
End Class