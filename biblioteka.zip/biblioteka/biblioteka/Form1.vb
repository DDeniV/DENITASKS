﻿Public Class frmHome

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnRomani_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRomani.Click
        frmRoman.Show()
    End Sub

    Private Sub btnKriminaleta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKriminaleta.Click
        frmKriminale.Show()
    End Sub

    Private Sub grpJanr_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles grpJanr.Enter

    End Sub

    Private Sub btnPrikluchenia_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrikluchenia.Click
        frmPrikluchenia.Show()
    End Sub

    Private Sub btnFantastika_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFantastika.Click
        frmFantastika.Show()
    End Sub

    Private Sub btnUzasi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUzasi.Click
        frmUzasi.Show()
    End Sub
End Class
